import torch
from torch.utils.data import Dataset, DataLoader
from transformers import LlamaForCausalLM, LlamaTokenizer, Trainer, TrainingArguments

# Step 3: Load and Parse Your Data
def load_data(file_path):
    requests = []
    responses = []

    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
        for line in lines:
            if line.startswith("request:"):
                request = line[len("request: "):].strip()
                requests.append(request)
            elif line.startswith("Response:"):
                response = line[len("Response: "):].strip()
                responses.append(response)

    # Combine requests and responses for training
    texts = [f"Request: {req}\nResponse: {res}" for req, res in zip(requests, responses)]
    return texts

# Load your custom data
file_path = "/home/kali/llama/responses.txt"
texts = load_data(file_path)

# Step 1: Prepare Your Data
class TextDataset(Dataset):
    def __init__(self, texts, tokenizer, max_length=512):
        self.texts = texts
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        encodings = self.tokenizer(
            self.texts[idx],
            truncation=True,
            padding="max_length",
            max_length=self.max_length,
            return_tensors="pt"
        )
        return {key: tensor.squeeze() for key, tensor in encodings.items()}

# Step 2: Load LLaMA Model and Tokenizer
tokenizer = LlamaTokenizer.from_pretrained("path_to_llama_checkpoint")
model = LlamaForCausalLM.from_pretrained("path_to_llama_checkpoint")

# Step 4: Create a DataLoader
dataset = TextDataset(texts, tokenizer)
dataloader = DataLoader(dataset, batch_size=4, shuffle=True)

# Step 5: Set Up Training Arguments
training_args = TrainingArguments(
    output_dir="./results",
    num_train_epochs=3,
    per_device_train_batch_size=4,
    save_steps=10_000,
    save_total_limit=2,
    logging_dir="./logs",
)

# Step 6: Initialize the Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset,
)

# Step 7: Train the Model
trainer.train()

# Step 8: Save the Fine-Tuned Model
model.save_pretrained("path_to_save_model")
tokenizer.save_pretrained("path_to_save_model")

# Step 9: Load the Model for Inference
model = LlamaForCausalLM.from_pretrained("path_to_save_model")
tokenizer = LlamaTokenizer.from_pretrained("path_to_save_model")

# Step 10: Generate Text
input_text = "Start of your prompt"
inputs = tokenizer(input_text, return_tensors="pt")
outputs = model.generate(**inputs)
print(tokenizer.decode(outputs[0]))
